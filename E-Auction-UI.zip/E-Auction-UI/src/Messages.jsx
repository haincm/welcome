/*
 * Copyright (c) 2021-Present, Okta, Inc. and/or its affiliates. All rights reserved.
 * The Okta software accompanied by this notice is provided pursuant to the Apache License, Version 2.0 (the "License.")
 *
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0.
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and limitations under the License.
 */

import { useOktaAuth } from '@okta/okta-react';
import React, { useState, useEffect } from 'react';
import { Header, Icon, Message, Table, Dropdown, Form} from 'semantic-ui-react';

import config from './config';

function getProducts(allProducts) {
  return allProducts.map(p => ({ value: p.id, text: p.productName,key:p.id }));
}
const Messages = () => {
  const { authState, oktaAuth } = useOktaAuth();
  const [products, setProducts] = useState(null);
  const [allProducts, setAllProducts] = useState(null);
  const [messageFetchFailed, setMessageFetchFailed] = useState(false);

  const handleOnChange = (e, data) => {
    console.log(data.value);
    const accessToken = oktaAuth.getAccessToken();
    fetch(config.resourceServer.prodcutUrl+data.value, { 
      headers: {
        "Access-Control-Allow-Origin": "*",
        Authorization: `Bearer ${accessToken}`
      },
    })
      .then((response) => {
        if (!response.ok) {
          return Promise.reject();
        }
        return response.json();
      })
      .then((data) => {
        let index = 0;        
        setProducts(data);
        console.log(data);
        setMessageFetchFailed(false);
      })
 }
  useEffect(() => {
    if (authState && authState.isAuthenticated) {
      const accessToken = oktaAuth.getAccessToken();
      fetch(config.resourceServer.messagesUrl, { 
        headers: {
          "Access-Control-Allow-Origin": "*",
          Authorization: `Bearer ${accessToken}`
        },
      })
        .then((response) => {
          if (!response.ok) {
            return Promise.reject();
          }
          return response.json();
        })
        .then((data) => {
          let index = 0;        
          setAllProducts(getProducts(data));
          console.log(getProducts(data));
          setMessageFetchFailed(false);
        })
        .catch((err) => {
          setMessageFetchFailed(true);
          /* eslint-disable no-console */
          console.error(err);
        });
    }
  }, [authState, oktaAuth]);


  const possibleErrors = [
    'You\'ve downloaded one of our resource server examples, and it\'s running on port 8000.',
    'Your resource server example is using the same Okta authorization server (issuer) that you have configured this React application to use.',
  ];
 
  
  return (
    <div>
      <Header as='h2' icon textAlign='center'>
      <Icon name='info circle' circular />
      <Header.Content>E-Auction Bid Information</Header.Content>
    </Header>
      {messageFetchFailed && <Message error header="Failed to fetch messages.  Please verify the following:" list={possibleErrors} />}
      {!allProducts && !messageFetchFailed && <p>Fetching Information..</p>}
      {allProducts
      && (
      <div>
       
        <Dropdown placeholder='Prodcut' fluid search selection options={allProducts} onChange={handleOnChange} />
        <Header as="h3">
        <Icon name="product hunt outline" />
        Products Details
      </Header>
        <Form>
          <Form.Field>
            <label>Prodcut Name</label>
            <input value={products && products[0].product.productName} placeholder='' />
          </Form.Field>
          <Form.Field>
            <label>Product Short Description</label>
            <input value={products && products[0].product.shortPrdDesc} placeholder='' />
          </Form.Field>
          <Form.Field>
          <label>Product Description</label>
          <input value={products && products[0].product.prdDesc} placeholder='' />
          </Form.Field>
          <Form.Field>
            <label>Prodcut Starting Price</label>
            <input value={products && products[0].product.startPrice} placeholder='' />            
          </Form.Field>
          <Form.Field>
            <label>Product Category</label>
            <input value={products && products[0].product.prdCategory} placeholder='' />
          </Form.Field>
          <Form.Field>
          <label>Product Bid End Date</label>
          <input value={products && products[0].product.bidEndDate} placeholder='' />
          </Form.Field>
          
        </Form>
        <p>         
         
        </p>
        <Header as="h3">
        <Icon name="user outline" />
        Bid Information
        </Header>
        <Table>
          <thead>
            <tr>
              <th>Bid Amount</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
            </tr>
          </thead>
          <tbody>
            {products && products.map((p) => (
              <tr id={p.id} key={p.id}>
                <td>{p.bidAmount}</td>
                <td>{p.buyer.firstName}</td>
                <td>{p.buyer.email}</td>
                <td>{p.buyer.phone}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
      )}
    </div>
  );
};

export default Messages;
