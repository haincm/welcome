package com.eauction.commandservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommandServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
