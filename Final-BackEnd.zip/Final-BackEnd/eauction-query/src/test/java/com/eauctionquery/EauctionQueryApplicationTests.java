package com.eauctionquery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EauctionQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
